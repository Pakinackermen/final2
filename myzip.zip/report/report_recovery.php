<div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4">
              <div class="col-12 col-sm-6 text-center text-sm-left mb-0">                
                <!-- <h4 class="col-12 col-sm-12 text-center">รายงานการกู้คืนข้อมูล</h4> -->
              </div>
            </div>
            <!-- End Page Header -->
            <!-- Default Light Table -->
            <div class="row">
              <div class="col">
                <div class="card card-small mb-4">
                  <div class="card-header border-bottom">
                    <h6 class="m-0">รายงานการกู้คืนข้อมูล</h6>
                  </div>
                  <div class="card-body p-0 pb-3 text-center">
                    <table class="table mb-0">
                      <thead class="bg-light">
                        <tr>
                          <th scope="col" class="border-0">#</th>
                          <th scope="col" class="border-0">ชื่อการสำรองข้อมูล</th>
                          <th scope="col" class="border-0">วันที่สำรองข้อมูล</th>
                          <th scope="col" class="border-0">ขนาด</th>                    
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>m</td>
                          <td>20-สค-61</td>
                          <td>1.4MB</td>  
                        </tr>
                                                
                        </tr>                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>