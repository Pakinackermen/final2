<?php 
       
?>
<div class="col-lg-12">
  <!-- Page Header -->
  <div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-12 text-center text-sm-left mb-0">
      <!-- <span class="text-uppercase page-subtitle">Overview</span> -->
      <h3 class="page-title">ระบบรายงาน</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-5">
      <ul class="list-group">
        <li class="list-group-item">
          
        </li>
        <li class="list-group-item">
          <a href="core.php?report=backup&page=report">รายงานการสำรองข้อมูล</a>
        </li>
        <li class="list-group-item">
          <a href="core.php?report=recovery&page=report">รายงานการกู้คืนข้อมูล</a>
        </li>
        <li class="list-group-item">
          <a href="core.php?report=report_fileserver&page=report">รายงานการเพิ่มลดและขนาดของไฟล์</a>
        </li>
      </ul>

    </div>
  </div>